#!/bin/sh

dd if=/dev/zero of=compressfile bs=2048 count=1048576

