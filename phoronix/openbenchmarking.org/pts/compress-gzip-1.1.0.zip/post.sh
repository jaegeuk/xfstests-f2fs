#!/bin/sh

rm -f compressfile
