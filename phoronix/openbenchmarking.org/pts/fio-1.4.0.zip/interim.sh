#!/bin/sh

cd fio-2.1.11/
rm -f iometer.0.0
