#!/bin/sh

echo "#!/bin/sh
tar -xjf \$TEST_EXTENDS/linux-2.6.32.tar.bz2" > unpack-linux
chmod +x unpack-linux


