#!/bin/sh

rm -rf linux-2.6.32

